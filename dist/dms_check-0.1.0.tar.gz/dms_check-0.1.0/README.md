# dms_check
Script to check Oracle data for DMS compatibility


poetry run ora_check --host 35.204.233.222 --user SYSTEM --password samet123  --service ORCL19